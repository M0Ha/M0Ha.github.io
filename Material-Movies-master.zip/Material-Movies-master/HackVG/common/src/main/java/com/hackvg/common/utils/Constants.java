package com.hackvg.common.utils;

/**
 * Created by saulmm on 31/01/15.
 */
public class Constants {

    public static final String API_KEY = "87a901020f496977f9d6d508c5d186ec";
    public static final String MOVIE_DB_HOST = "http://api.themoviedb.org/3/";
    public static String BASIC_STATIC_URL = "";
}
