package com.hackvg.domain;

/**
 * Created by saulmm on 31/01/15.
 */
public interface Usecase {

    void execute ();
}
