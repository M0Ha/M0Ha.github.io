package com.hackvg.domain;

public class MyClass {
}
