This projects support a series of articles about how to setup an android environment to develop an scalable, maintainable and testable projects.

### A useful stack on android 

- [Architecture](http://saulmm.github.io/2015/02/02/A%20useful%20stack%20on%20android%20%231,%20architecture/) 

- [User interface](http://saulmm.github.io/a-useful-stack-on-android-2-user-interface/)

- [Compatibility](http://saulmm.github.io/a-useful-stack-on-android-3-compatibility/)

### Screenshots

![](http://androcode.es/wp-content/uploads/2015/03/family2.png)

![](http://androcode.es/wp-content/uploads/2015/03/detailFamily-e1426180053215.png)